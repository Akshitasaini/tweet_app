package com.tweetapp.service;

import java.io.IOException;
import java.sql.SQLException;

import com.tweetapp.model.User;

public interface LoginService {
	public User loginUser(String userName, String password) throws SQLException, IOException;

}
