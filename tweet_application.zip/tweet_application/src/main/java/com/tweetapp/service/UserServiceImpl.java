package com.tweetapp.service;

import java.io.IOException;

import java.sql.SQLException;

import com.tweetapp.dao.UserDao;
import com.tweetapp.dao.UserDaoImpl;
import com.tweetapp.model.User;

public class UserServiceImpl implements UserService {
	private UserDao dao;
	{
		dao = new UserDaoImpl();
	}

	@Override
	public User createUser(String firstName, String lastName, String gender, String dob, String email, String password)
			throws SQLException {
		return dao.createUser(firstName, lastName, gender, dob, email, password);
	}

	@Override
	public User updatePassword(String updatePass) throws SQLException, IOException {
		return dao.updatePassword(updatePass);
	}

}
