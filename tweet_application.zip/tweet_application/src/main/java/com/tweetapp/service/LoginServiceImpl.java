package com.tweetapp.service;

import java.io.IOException;

import java.sql.SQLException;

import com.tweetapp.dao.LoginDao;
import com.tweetapp.dao.LoginImpl;

import com.tweetapp.model.User;

public class LoginServiceImpl implements LoginService {
	private LoginDao dao;
	{
		dao = new LoginImpl();
	}

	@Override
	public User loginUser(String userName, String password) throws SQLException, IOException {
		// TODO Auto-generated method stub
		return dao.loginUser(userName, password);
	}
}
