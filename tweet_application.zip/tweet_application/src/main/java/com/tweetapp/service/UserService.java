package com.tweetapp.service;

import java.io.IOException;

import java.sql.SQLException;

import com.tweetapp.model.User;

public interface UserService {
	public User createUser(String firstName, String lastName, String gender, String dob, String email, String password)
			throws SQLException;

	User updatePassword(String updatePass) throws SQLException, IOException;
}
