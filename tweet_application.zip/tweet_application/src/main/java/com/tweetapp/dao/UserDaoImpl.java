package com.tweetapp.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.tweetapp.connection.MyConnection;
import com.tweetapp.model.User;

public class UserDaoImpl implements UserDao {
	private MyConnection myConnection = null;
	private Connection connection = null;
	private User user = null;
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	PreparedStatement pStatement = null;
	{
		myConnection = MyConnection.getMyConnectionObject();
		try {
			connection = myConnection.getMyConnection();
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public User createUser(String firstName, String lastName, String gender, String dob, String email, String password)
			throws SQLException {

		user = new User(firstName, lastName, gender, dob, email, password);
		pStatement = connection.prepareStatement(
				"insert into user(first_name,last_name,gender,d_o_b,email,password) values(?,?,?,?,?,?)");
		pStatement.setString(1, user.getFirstName());
		pStatement.setString(2, user.getLastName());
		pStatement.setString(3, user.getGender());
		pStatement.setString(4, user.getDob());
		pStatement.setString(5, user.getEmail());
		pStatement.setString(6, user.getPassword());
		pStatement.executeUpdate();
		return user;
	}

	@Override
	public User updatePassword(String updatePass) throws SQLException, IOException {

		updatePass = br.readLine().toString();
		pStatement = connection.prepareStatement("update user set password=updatePass where email = s");
		pStatement.setString(1, updatePass);

		System.out.println("The password is updated!");
		return user;
	}

}
