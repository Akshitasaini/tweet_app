package com.tweetapp.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.tweetapp.connection.MyConnection;
import com.tweetapp.model.Post;
import com.tweetapp.model.User;

public class LoginImpl implements LoginDao {
	private MyConnection myConnection = null;
	private Connection connection = null;
	private User user = null;

	private Post posts = null;
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	PreparedStatement pStatement = null;
	{
		myConnection = MyConnection.getMyConnectionObject();
		try {
			connection = myConnection.getMyConnection();
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public User loginUser(String userName, String password) throws SQLException, IOException {
		user = new User(userName, password);

		String email = user.getEmail();
		String pass = user.getPassword();
		int choice = 0;
		Statement statement = null;
		ResultSet resultSet = null;

		String userNameDB = "";
		String passwordDB = "";

		try {
			connection = myConnection.getMyConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery("select email,password from user");

			while (resultSet.next()) // true til next row
			{
				userNameDB = resultSet.getString("email");
				passwordDB = resultSet.getString("password");

				if (email.equals(userNameDB) && pass.equals(passwordDB)) {
					System.out.println(" Logged in: ");
					System.out.println("1. Post tweet");
					System.out.println("2. View all tweets");
					System.out.println("3. View all registered users");
					System.out.println("4. Reset password");
					System.out.println("5. Log Out");
					choice = Integer.parseInt(br.readLine().toString());
					switch (choice) {
					case 1:
						System.out.println(" Tweeets :");
						String p = br.readLine().toString();

						posts = new Post(p);
						pStatement = connection.prepareStatement("insert into posts(post) values(?) ");
						pStatement.setString(1, posts.getPosts());

						pStatement.executeUpdate();
						System.out.println("The tweets: " + p);
						break;
					case 2:

						String pss = "";

						connection = myConnection.getMyConnection();
						statement = connection.createStatement();
						resultSet = statement.executeQuery("select * from posts");
						while (resultSet.next()) // true til next row
						{
							pss = resultSet.getString("post");

							System.out.println("The Posts :" + pss);
						}

						break;

					case 3:

						String users = "";

						connection = myConnection.getMyConnection();
						statement = connection.createStatement();
						resultSet = statement.executeQuery("select first_name from user");

						while (resultSet.next()) // true til next row
						{
							users = resultSet.getString("first_name");

							System.out.println(users);

						}

						break;

					case 4:
						System.out.println("Enter the new password : ");

						String s = br.readLine().toString();

						pStatement = connection.prepareStatement("update user set password= ? where email=? ");
						pStatement.setString(1, s);
						pStatement.setString(2, user.getEmail());

						pStatement.executeUpdate();
						System.out.println("The Password updated successfully!!!! ");
						break;

					case 5:
						System.out.println("Logged Out Successfully");
						System.exit(0);

						break;

					}
				}

			}
			System.out.println("Invalid credentials....");

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;

	}

}
