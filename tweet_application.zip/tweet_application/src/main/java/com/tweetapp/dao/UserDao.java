package com.tweetapp.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.tweetapp.model.User;

public interface UserDao {

	public User createUser(String firstName, String lastName, String gender, String dob, String email, String password)
			throws SQLException, SQLException;

	User updatePassword(String updatePass) throws SQLException, IOException;

}
