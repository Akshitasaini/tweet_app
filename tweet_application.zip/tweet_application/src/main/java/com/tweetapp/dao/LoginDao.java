package com.tweetapp.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.tweetapp.model.User;

public interface LoginDao {
	public User loginUser(String userName, String password) throws SQLException, IOException;

}
