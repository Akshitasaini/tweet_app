package com.tweetapp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

import com.tweetapp.model.User;
import com.tweetapp.service.LoginService;
import com.tweetapp.service.LoginServiceImpl;
import com.tweetapp.service.UserService;
import com.tweetapp.service.UserServiceImpl;

public class LoginApp {
	private static LoginService loginService;
	static {
		loginService = new LoginServiceImpl();
	}
	private static UserService userService;
	static {
		userService = new UserServiceImpl();
	}

	public static void main(String[] args) throws NumberFormatException, IOException, SQLException {
		int choice = 0;

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		do {
			System.out.println("1. Login");
			System.out.println("2. Register");
			System.out.println("3. Forgot Password");
			System.out.println("Choice:  ");
			choice = Integer.parseInt(br.readLine().toString());
			switch (choice) {
			case 1:
				System.out.println("UserName: ");
				String uName = br.readLine().toString();
				System.out.println(" Password: ");
				String pass = br.readLine().toString();
				User log = loginService.loginUser(uName, pass);

				break;
			case 2:

				System.out.println(" First Name: ");
				String fName = br.readLine().toString();
				System.out.println(" Last Name: ");
				String lName = br.readLine().toString();
				System.out.println(" Gender: ");
				String gender = br.readLine().toString();
				System.out.println(" dob: ");
				String dob = br.readLine().toString();
				System.out.println(" Email: ");
				String email = br.readLine().toString();
				System.out.println(" Password: ");
				String password = br.readLine().toString();
				User user = userService.createUser(fName, lName, gender, dob, email, password);
				System.out.println("User created successfully!");
				break;
			case 3:
				System.out.println("Enter your UserName/Email ");

				String updateP = br.readLine().toString();
				User use = userService.updatePassword(updateP);
				System.out.println(use);
				break;

			default:
				System.out.println("Invalid");
				break;
			}

		} while (choice != 0);

	}

}
