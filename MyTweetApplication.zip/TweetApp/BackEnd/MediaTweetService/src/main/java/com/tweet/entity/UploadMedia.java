package com.tweet.entity;


import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor@NoArgsConstructor
@Document(collection = "Media")
public class UploadMedia {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int uid;
	private String title;
	private String description;
	private String tags;
	
	private String date;
	private String username;
	  
     
	public UploadMedia(int id, int uid, String title, String description, String tags) {
		super();
		this.id = id;
		this.uid = uid;
		this.title = title;
		this.description = description;
		this.tags = tags;
		
	}


	public UploadMedia(int uid, String title, String description, String tags,String date,String username) {
		super();
		this.uid = uid;
		this.title = title;
		this.description = description;
		this.tags = tags;
		
		this.username = username;
		this.setDate(date);
		//this.currentDate = currentDate;
	}

	
	
	
	
}
