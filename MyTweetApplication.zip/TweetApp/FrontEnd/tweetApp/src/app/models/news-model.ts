export class NewsFeed {
  constructor(
    public date: string,
    public time: string,
    public activity: string
  ) {}
}
